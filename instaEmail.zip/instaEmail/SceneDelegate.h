//
//  SceneDelegate.h
//  instaEmail
//
//  Created by Sami Bajwa on 2/6/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

