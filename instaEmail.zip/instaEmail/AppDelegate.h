//
//  AppDelegate.h
//  instaEmail
//
//  Created by Sami Bajwa on 2/6/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

