//
//  ViewController.h
//  instaEmail
//
//  Created by Sami Bajwa on 2/6/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
<UIPickerViewDataSource, UIPickerViewDelegate> {
    NSArray* activities_;
    NSArray* feelings_;
}

@end

